# ReadContentPlugin
This is simple ReadContentPlugin
