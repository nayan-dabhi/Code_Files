package com.aau.gsaucaadmission;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import android.util.Log;


public class ReadContentPlugin extends CordovaPlugin {
	public static String ACTION_READ_CONTENT="read_content";
	
	@Override
	public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {

		// TODO Auto-generated method stub
		try {
			if(ACTION_READ_CONTENT.equals(action)){
				// Log.w("cached_data","-------------------------"+loadJSONFromSdcard());
				Log.w("args","args from read plugin:" + args.toString());
				callbackContext.success(loadJSONFromSdcard());
				return true;
			}

			return true;
		} catch(Exception e) {
			Log.w("Exception :","problem is :"+e.getMessage());
			callbackContext.error(e.getMessage());
			return false;
		}
	}

	public String loadJSONFromSdcard() {
        String json = null;

        try {
        	File f = new File(GlobalApp.getAppDirPathFull());
        	final File myFile = new File(f, GlobalApp.CACHED_FILE_NAME);
            FileInputStream is = new FileInputStream(myFile);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }

        return json;
    }
}