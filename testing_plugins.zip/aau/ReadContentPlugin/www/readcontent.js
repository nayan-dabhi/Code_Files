/*global cordova, module*/

module.exports = {
    readMethod: function (title, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, "ReadContentPlugin", 'read_content',[{
        "title": title
      }]);
    }
};
