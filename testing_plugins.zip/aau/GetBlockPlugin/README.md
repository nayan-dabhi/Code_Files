# GetBlockPlugin
This is simple GetBlockPlugin for block of data
