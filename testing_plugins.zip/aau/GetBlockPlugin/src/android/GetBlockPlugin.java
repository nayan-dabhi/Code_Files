package com.aau.gsaucaadmission;

import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetBlockPlugin extends CordovaPlugin{
	public static String ACTION_TARGET_BLOCK="target_block";

	@Override
	public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {

		// TODO Auto-generated method stub
		try {
			if(ACTION_TARGET_BLOCK.equals(action)){
				JSONObject dataObject=args.getJSONObject(0);
				Log.w("id",dataObject.getString("parent_id"));

				JSONObject targetNode=getTargetNode(dataObject.getString("parent_id"), dataObject.getString("child_id"));
				if(targetNode==null){
					callbackContext.error("");
					return false;
				} else {
					callbackContext.success(targetNode);
					Log.w("plugin_json", "block : "+targetNode.toString());
					Log.w("plugin_json", "json block success");
					return true;
				}
			}

			return true;
		} catch(Exception e) {
			Log.w("Exception :","problem is :"+e.getMessage());
			callbackContext.error(e.getMessage());
			return false;
		}
	}

	public JSONObject getTargetNode(String parentId,String childId){
		JSONObject dataToReturn=null;
		boolean dataFound=false;
		String targetData=loadJSONFromSdcard();

		try {
			JSONArray parentArr=new JSONArray(targetData);
			JSONArray innerObjects=null;
			JSONObject innerObj=null;

			for(int i=0; i<parentArr.length(); i++){
				innerObj=parentArr.getJSONObject(i);

				if(innerObj.getString("id").equals(parentId)){
					innerObjects=innerObj.getJSONArray("subtopics");

					for(int j=0; j<innerObjects.length(); j++){
						innerObj=innerObjects.getJSONObject(j);
						if(innerObj.getString("id").equals(childId)){
							dataToReturn=innerObj;
							dataFound=true;
							break;
						}
					}
				}

				if(dataFound){
					break;
				}
			}
		} catch(JSONException jex) {
			dataToReturn=null;
		}

		return dataToReturn;
	}

	public String loadJSONFromSdcard() {
		String json = null;

		try {
			File f = new File(GlobalApp.getAppDirPathFull());
			final File myFile = new File(f, GlobalApp.CACHED_FILE_NAME);
			FileInputStream is = new FileInputStream(myFile);
			int size = is.available();
			byte[] buffer = new byte[size];
			is.read(buffer);
			is.close();
			json = new String(buffer, "UTF-8");
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}

		return json;
	}
}