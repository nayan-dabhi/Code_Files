/*global cordova, module*/

module.exports = {
    targetMethod: function (parentId, childId, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, "GetBlockPlugin", 'target_block',[{
        "parent_id":parentId,
        "child_id":childId
      }]);
    }
};
