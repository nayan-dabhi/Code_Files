/*global cordova, module*/

module.exports = {
    writeMethod: function (title, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, "WriteContentPlugin", 'write_content',[{
        "title": title
      }]);
    }
};
