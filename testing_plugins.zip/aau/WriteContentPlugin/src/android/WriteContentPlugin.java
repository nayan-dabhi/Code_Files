package com.aau.gsaucaadmission;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.util.Log;

import org.apache.cordova.*;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.aau.gsaucaadmission.service.UserActionService;

public class WriteContentPlugin extends CordovaPlugin {
    public static String ACTION_WRITE_CONTENT = "write_content";
    public static String appDirectoryName = "iKisaan";
    UserActionService syncService;
    File f = null;

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {

        // TODO Auto-generated method stub
        manageAppFolders();
        syncService = new UserActionService();

        try {
            if(ACTION_WRITE_CONTENT.equals(action)){
                JSONObject jObj = args.getJSONObject(0);
                String title = jObj.getString("title");
                //Log.w("args","args from write plugin:"+args.toString());
                //new Thread(syncService).start();
                cacheToFile(GlobalApp.CACHED_FILE_NAME, title);
                callbackContext.success();
                return true;
            }
            return true;
        } catch(Exception e){
            Log.w("Exception :","problem is :" + e.getMessage());
            callbackContext.error(e.getMessage());
            return false;
        }
    }

    public void cacheToFile(String fileName, String body){
        FileOutputStream fos = null;

        try {
            //final File dir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/folderName/" );
            f = new File(GlobalApp.getAppDirPathFull());
            final File myFile = new File(f, fileName);

            if (!myFile.exists()){
                myFile.createNewFile();
                Log.w("cache", "file created");
            }

            fos = new FileOutputStream(myFile);
            fos.write(body.getBytes());
            fos.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void manageAppFolders(){
        File parentDir=new File(GlobalApp.getAppDirPathFull());
        Log.w("from_plugin", "inside manage app folder method");

        if(!parentDir.exists()){
            parentDir.mkdir();
            Log.w("from_plugin", "inside if condition");
        }
    }
}